<?php
return [
    'name' => 'Evotech Africa',
    'base_url' => 'http://localhost/Evotech_Africa_MVC_Enterprise/public',
    'timezone' => 'Africa/Kinshasa',
    'debug' => true
];
