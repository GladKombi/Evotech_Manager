<?php
return [
    'DG' => ['*'],
    'ChefDepartement' => ['departements','agents','contrats-com','activites-contrat','dashboard'],
    'Chef_projet' => ['projets','taches','timesheets','productions','dashboard'],
    'comptable' => ['comptes','mouvements','transferts','dashboard'],
    'actionnaire' => ['dashboard','projets','comptes'],
    'Agent' => ['taches','timesheets','productions','dashboard']
];
