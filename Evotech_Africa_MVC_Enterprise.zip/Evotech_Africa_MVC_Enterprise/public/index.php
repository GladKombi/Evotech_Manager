<?php
declare(strict_types=1);
session_start();
require_once dirname(__DIR__) . '/vendor/autoload.php';

use App\Core\Router;
use App\Core\Helpers;

$router = new Router();
require dirname(__DIR__) . '/routes/web.php';
$router->dispatch($_SERVER['REQUEST_METHOD'], Helpers::currentPath());
