<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\ActiviteContrat;
class ActiviteContratController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new ActiviteContrat(); $this->view('activites-contrat/index',['title'=>'Activites Contrat','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new ActiviteContrat(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('activites-contrat'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new ActiviteContrat())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('activites-contrat'); }
}
