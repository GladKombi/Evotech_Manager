<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\Projet;
class ProjetController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new Projet(); $this->view('projets/index',['title'=>'Projets','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new Projet(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('projets'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new Projet())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('projets'); }
}
