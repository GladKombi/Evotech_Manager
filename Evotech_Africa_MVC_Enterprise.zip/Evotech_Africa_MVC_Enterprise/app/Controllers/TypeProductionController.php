<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\TypeProduction;
class TypeProductionController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new TypeProduction(); $this->view('types-production/index',['title'=>'Types Production','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new TypeProduction(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('types-production'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new TypeProduction())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('types-production'); }
}
