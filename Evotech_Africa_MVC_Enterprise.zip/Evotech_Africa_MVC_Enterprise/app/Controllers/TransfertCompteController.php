<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\TransfertCompte;
class TransfertCompteController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new TransfertCompte(); $this->view('transferts/index',['title'=>'Transferts','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new TransfertCompte(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('transferts'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new TransfertCompte())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('transferts'); }
}
