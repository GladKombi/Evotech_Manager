<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\Utilisateur;
class UtilisateurController extends Controller {
    public function index(): void { Auth::requireAuth(); $this->view('utilisateurs/index',['title'=>'Gestion des Utilisateurs','items'=>(new Utilisateur())->withRoles()]); }
    public function store(): void { Auth::requireAuth(); $data=['nom'=>$_POST['nom']??'','prenom'=>$_POST['prenom']??'','email'=>$_POST['email']??null,'mot_de_passe_hash'=>password_hash($_POST['password']??'123456',PASSWORD_DEFAULT),'actif'=>isset($_POST['actif'])?1:0]; (new Utilisateur())->create($data); Session::flash('success','Utilisateur créé'); Helpers::redirect('utilisateurs'); }
    public function delete(): void { Auth::requireAuth(); (new Utilisateur())->softDelete((int)($_POST['id']??0)); Session::flash('success','Utilisateur supprimé'); Helpers::redirect('utilisateurs'); }
}
