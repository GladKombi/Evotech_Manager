<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\MouvementCompte;
class MouvementCompteController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new MouvementCompte(); $this->view('mouvements/index',['title'=>'Mouvements','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new MouvementCompte(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('mouvements'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new MouvementCompte())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('mouvements'); }
}
