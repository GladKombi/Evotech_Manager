<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\Production;
class ProductionController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new Production(); $this->view('productions/index',['title'=>'Productions','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new Production(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('productions'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new Production())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('productions'); }
}
