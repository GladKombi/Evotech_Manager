<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Database;
class DashboardController extends Controller {
    public function index(): void { Auth::requireAuth(); $db=Database::conn(); $stats=[]; foreach(['UTILISATEURS','AGENTS','PROJETS','PARTENAIRES','COMPTES','PRODUCTION'] as $t){ $stats[$t]=(int)$db->query("SELECT COUNT(*) FROM $t WHERE statut=0")->fetchColumn(); } $this->view('dashboard/index',['title'=>'Tableau de bord','stats'=>$stats]); }
}
