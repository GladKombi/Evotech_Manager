<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\ContratCom;
class ContratComController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new ContratCom(); $this->view('contrats-com/index',['title'=>'Contrats Com','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new ContratCom(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('contrats-com'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new ContratCom())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('contrats-com'); }
}
