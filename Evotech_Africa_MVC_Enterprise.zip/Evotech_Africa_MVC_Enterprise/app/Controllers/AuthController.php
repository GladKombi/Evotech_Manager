<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Database; use App\Core\Session; use App\Core\Helpers;
class AuthController extends Controller {
    public function login(): void { $this->authView('auth/login', ['title'=>'Connexion']); }
    public function authenticate(): void {
        $email=$_POST['email']??''; $pass=$_POST['password']??'';
        $s=Database::conn()->prepare('SELECT * FROM UTILISATEURS WHERE email=? AND statut=0 LIMIT 1'); $s->execute([$email]); $u=$s->fetch();
        if($u && password_verify($pass,$u['mot_de_passe_hash'])){ Session::setUser($u); Helpers::redirect('dashboard'); }
        Session::flash('error','Email ou mot de passe incorrect'); Helpers::redirect('login');
    }
    public function logout(): void { Session::destroy(); Helpers::redirect('login'); }
}
