<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\Agent;
class AgentController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new Agent(); $this->view('agents/index',['title'=>'Agents','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new Agent(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('agents'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new Agent())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('agents'); }
}
