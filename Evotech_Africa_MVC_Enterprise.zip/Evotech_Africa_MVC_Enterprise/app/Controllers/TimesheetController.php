<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\Timesheet;
class TimesheetController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new Timesheet(); $this->view('timesheets/index',['title'=>'Timesheets','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new Timesheet(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('timesheets'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new Timesheet())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('timesheets'); }
}
