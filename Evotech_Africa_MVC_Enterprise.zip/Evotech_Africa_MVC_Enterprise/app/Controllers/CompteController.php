<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\Compte;
class CompteController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new Compte(); $this->view('comptes/index',['title'=>'Comptes','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new Compte(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('comptes'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new Compte())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('comptes'); }
}
