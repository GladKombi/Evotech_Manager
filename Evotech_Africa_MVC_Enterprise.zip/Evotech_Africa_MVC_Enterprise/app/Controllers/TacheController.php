<?php
namespace App\Controllers;
use App\Core\Controller; use App\Core\Auth; use App\Core\Helpers; use App\Core\Session; use App\Models\Tache;
class TacheController extends Controller {
    public function index(): void { Auth::requireAuth(); $model=new Tache(); $this->view('taches/index',['title'=>'Taches','items'=>$model->all()]); }
    public function store(): void { Auth::requireAuth(); $model=new Tache(); $data=$_POST; unset($data['_csrf']); $model->create($data); Session::flash('success','Enregistrement effectué avec succès'); Helpers::redirect('taches'); }
    public function delete(): void { Auth::requireAuth(); $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0); (new Tache())->softDelete($id); Session::flash('success','Suppression effectuée'); Helpers::redirect('taches'); }
}
