<div class="page-head"><div><h1><?= App\Core\Helpers::e($title) ?></h1><p>Gestion du module Projets</p></div><button class="btn-primary" onclick="openModal('modalForm')">+ Ajouter</button></div>
<div class="card"><table><thead><tr><th>reference</th><th>titre</th><th>etat</th><th>priorite</th><th>budget_estime</th><th>Actions</th></tr></thead><tbody>
<?php foreach($items as $item): ?><tr><td><?= App\Core\Helpers::e($item['reference'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['titre'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['etat'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['priorite'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['budget_estime'] ?? '') ?></td><td><form method="post" action="<?= App\Core\Helpers::url('projets/delete') ?>"><input type="hidden" name="id" value="<?= $item['projet_id'] ?>"><button class="btn-danger">Supprimer</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<div id="modalForm" class="modal"><div class="modal-box"><h2>Ajouter</h2><form method="post" action="<?= App\Core\Helpers::url('projets/store') ?>"><label>reference<input name="reference" class="form-control"></label>
<label>titre<input name="titre" class="form-control"></label>
<label>etat<input name="etat" class="form-control"></label>
<label>priorite<input name="priorite" class="form-control"></label>
<label>budget_estime<input name="budget_estime" class="form-control"></label><div class="actions"><button type="button" onclick="closeModal('modalForm')">Annuler</button><button class="btn-primary">Enregistrer</button></div></form></div></div>
