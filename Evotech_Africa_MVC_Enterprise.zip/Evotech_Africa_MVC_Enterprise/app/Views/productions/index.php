<div class="page-head"><div><h1><?= App\Core\Helpers::e($title) ?></h1><p>Gestion du module Productions</p></div><button class="btn-primary" onclick="openModal('modalForm')">+ Ajouter</button></div>
<div class="card"><table><thead><tr><th>nom_fichier</th><th>chemin_stockage</th><th>confidentialite</th><th>date_upload</th><th>Actions</th></tr></thead><tbody>
<?php foreach($items as $item): ?><tr><td><?= App\Core\Helpers::e($item['nom_fichier'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['chemin_stockage'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['confidentialite'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['date_upload'] ?? '') ?></td><td><form method="post" action="<?= App\Core\Helpers::url('productions/delete') ?>"><input type="hidden" name="id" value="<?= $item['production_id'] ?>"><button class="btn-danger">Supprimer</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<div id="modalForm" class="modal"><div class="modal-box"><h2>Ajouter</h2><form method="post" action="<?= App\Core\Helpers::url('productions/store') ?>"><label>nom_fichier<input name="nom_fichier" class="form-control"></label>
<label>chemin_stockage<input name="chemin_stockage" class="form-control"></label>
<label>confidentialite<input name="confidentialite" class="form-control"></label>
<label>date_upload<input name="date_upload" class="form-control"></label><div class="actions"><button type="button" onclick="closeModal('modalForm')">Annuler</button><button class="btn-primary">Enregistrer</button></div></form></div></div>
