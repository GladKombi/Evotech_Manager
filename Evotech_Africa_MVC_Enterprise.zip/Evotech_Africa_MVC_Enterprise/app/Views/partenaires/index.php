<div class="page-head"><div><h1><?= App\Core\Helpers::e($title) ?></h1><p>Gestion du module Partenaires</p></div><button class="btn-primary" onclick="openModal('modalForm')">+ Ajouter</button></div>
<div class="card"><table><thead><tr><th>nom</th><th>type</th><th>telephone</th><th>email</th><th>Actions</th></tr></thead><tbody>
<?php foreach($items as $item): ?><tr><td><?= App\Core\Helpers::e($item['nom'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['type'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['telephone'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['email'] ?? '') ?></td><td><form method="post" action="<?= App\Core\Helpers::url('partenaires/delete') ?>"><input type="hidden" name="id" value="<?= $item['partenaire_id'] ?>"><button class="btn-danger">Supprimer</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<div id="modalForm" class="modal"><div class="modal-box"><h2>Ajouter</h2><form method="post" action="<?= App\Core\Helpers::url('partenaires/store') ?>"><label>nom<input name="nom" class="form-control"></label>
<label>type<input name="type" class="form-control"></label>
<label>telephone<input name="telephone" class="form-control"></label>
<label>email<input name="email" class="form-control"></label><div class="actions"><button type="button" onclick="closeModal('modalForm')">Annuler</button><button class="btn-primary">Enregistrer</button></div></form></div></div>
