<div class="page-head"><div><h1><?= App\Core\Helpers::e($title) ?></h1><p>Gestion du module Taches</p></div><button class="btn-primary" onclick="openModal('modalForm')">+ Ajouter</button></div>
<div class="card"><table><thead><tr><th>description_tache</th><th>priorite</th><th>etat</th><th>estimation_heures</th><th>Actions</th></tr></thead><tbody>
<?php foreach($items as $item): ?><tr><td><?= App\Core\Helpers::e($item['description_tache'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['priorite'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['etat'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['estimation_heures'] ?? '') ?></td><td><form method="post" action="<?= App\Core\Helpers::url('taches/delete') ?>"><input type="hidden" name="id" value="<?= $item['tache_id'] ?>"><button class="btn-danger">Supprimer</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<div id="modalForm" class="modal"><div class="modal-box"><h2>Ajouter</h2><form method="post" action="<?= App\Core\Helpers::url('taches/store') ?>"><label>description_tache<input name="description_tache" class="form-control"></label>
<label>priorite<input name="priorite" class="form-control"></label>
<label>etat<input name="etat" class="form-control"></label>
<label>estimation_heures<input name="estimation_heures" class="form-control"></label><div class="actions"><button type="button" onclick="closeModal('modalForm')">Annuler</button><button class="btn-primary">Enregistrer</button></div></form></div></div>
