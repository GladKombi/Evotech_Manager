<div class="page-head"><div><h1><?= App\Core\Helpers::e($title) ?></h1><p>Gestion du module Agents</p></div><button class="btn-primary" onclick="openModal('modalForm')">+ Ajouter</button></div>
<div class="card"><table><thead><tr><th>nom</th><th>prenom</th><th>etat</th><th>date_embauche</th><th>Actions</th></tr></thead><tbody>
<?php foreach($items as $item): ?><tr><td><?= App\Core\Helpers::e($item['nom'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['prenom'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['etat'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['date_embauche'] ?? '') ?></td><td><form method="post" action="<?= App\Core\Helpers::url('agents/delete') ?>"><input type="hidden" name="id" value="<?= $item['agent_id'] ?>"><button class="btn-danger">Supprimer</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<div id="modalForm" class="modal"><div class="modal-box"><h2>Ajouter</h2><form method="post" action="<?= App\Core\Helpers::url('agents/store') ?>"><label>nom<input name="nom" class="form-control"></label>
<label>prenom<input name="prenom" class="form-control"></label>
<label>etat<input name="etat" class="form-control"></label>
<label>date_embauche<input name="date_embauche" class="form-control"></label><div class="actions"><button type="button" onclick="closeModal('modalForm')">Annuler</button><button class="btn-primary">Enregistrer</button></div></form></div></div>
