<div class="page-head"><div><h1><?= App\Core\Helpers::e($title) ?></h1><p>Gestion du module Disks</p></div><button class="btn-primary" onclick="openModal('modalForm')">+ Ajouter</button></div>
<div class="card"><table><thead><tr><th>matricule</th><th>capacite_go</th><th>etat</th><th>Actions</th></tr></thead><tbody>
<?php foreach($items as $item): ?><tr><td><?= App\Core\Helpers::e($item['matricule'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['capacite_go'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['etat'] ?? '') ?></td><td><form method="post" action="<?= App\Core\Helpers::url('disks/delete') ?>"><input type="hidden" name="id" value="<?= $item['disk_id'] ?>"><button class="btn-danger">Supprimer</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<div id="modalForm" class="modal"><div class="modal-box"><h2>Ajouter</h2><form method="post" action="<?= App\Core\Helpers::url('disks/store') ?>"><label>matricule<input name="matricule" class="form-control"></label>
<label>capacite_go<input name="capacite_go" class="form-control"></label>
<label>etat<input name="etat" class="form-control"></label><div class="actions"><button type="button" onclick="closeModal('modalForm')">Annuler</button><button class="btn-primary">Enregistrer</button></div></form></div></div>
