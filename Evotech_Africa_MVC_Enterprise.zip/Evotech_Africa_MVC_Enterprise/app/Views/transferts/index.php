<div class="page-head"><div><h1><?= App\Core\Helpers::e($title) ?></h1><p>Gestion du module Transferts</p></div><button class="btn-primary" onclick="openModal('modalForm')">+ Ajouter</button></div>
<div class="card"><table><thead><tr><th>montant</th><th>motif</th><th>reference_transfert</th><th>date_transfert</th><th>Actions</th></tr></thead><tbody>
<?php foreach($items as $item): ?><tr><td><?= App\Core\Helpers::e($item['montant'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['motif'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['reference_transfert'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['date_transfert'] ?? '') ?></td><td><form method="post" action="<?= App\Core\Helpers::url('transferts/delete') ?>"><input type="hidden" name="id" value="<?= $item['transfert_id'] ?>"><button class="btn-danger">Supprimer</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<div id="modalForm" class="modal"><div class="modal-box"><h2>Ajouter</h2><form method="post" action="<?= App\Core\Helpers::url('transferts/store') ?>"><label>montant<input name="montant" class="form-control"></label>
<label>motif<input name="motif" class="form-control"></label>
<label>reference_transfert<input name="reference_transfert" class="form-control"></label>
<label>date_transfert<input name="date_transfert" class="form-control"></label><div class="actions"><button type="button" onclick="closeModal('modalForm')">Annuler</button><button class="btn-primary">Enregistrer</button></div></form></div></div>
