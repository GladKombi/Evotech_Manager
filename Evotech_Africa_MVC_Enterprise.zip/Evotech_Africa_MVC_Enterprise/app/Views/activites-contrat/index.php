<div class="page-head"><div><h1><?= App\Core\Helpers::e($title) ?></h1><p>Gestion du module Activites Contrat</p></div><button class="btn-primary" onclick="openModal('modalForm')">+ Ajouter</button></div>
<div class="card"><table><thead><tr><th>description_activite</th><th>date_activite</th><th>cout</th><th>statut_activite</th><th>Actions</th></tr></thead><tbody>
<?php foreach($items as $item): ?><tr><td><?= App\Core\Helpers::e($item['description_activite'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['date_activite'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['cout'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['statut_activite'] ?? '') ?></td><td><form method="post" action="<?= App\Core\Helpers::url('activites-contrat/delete') ?>"><input type="hidden" name="id" value="<?= $item['activite_id'] ?>"><button class="btn-danger">Supprimer</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<div id="modalForm" class="modal"><div class="modal-box"><h2>Ajouter</h2><form method="post" action="<?= App\Core\Helpers::url('activites-contrat/store') ?>"><label>description_activite<input name="description_activite" class="form-control"></label>
<label>date_activite<input name="date_activite" class="form-control"></label>
<label>cout<input name="cout" class="form-control"></label>
<label>statut_activite<input name="statut_activite" class="form-control"></label><div class="actions"><button type="button" onclick="closeModal('modalForm')">Annuler</button><button class="btn-primary">Enregistrer</button></div></form></div></div>
