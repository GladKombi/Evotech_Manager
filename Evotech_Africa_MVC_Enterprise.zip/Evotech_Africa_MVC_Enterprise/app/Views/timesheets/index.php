<div class="page-head"><div><h1><?= App\Core\Helpers::e($title) ?></h1><p>Gestion du module Timesheets</p></div><button class="btn-primary" onclick="openModal('modalForm')">+ Ajouter</button></div>
<div class="card"><table><thead><tr><th>date_travail</th><th>worked_heures</th><th>etat</th><th>Actions</th></tr></thead><tbody>
<?php foreach($items as $item): ?><tr><td><?= App\Core\Helpers::e($item['date_travail'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['worked_heures'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['etat'] ?? '') ?></td><td><form method="post" action="<?= App\Core\Helpers::url('timesheets/delete') ?>"><input type="hidden" name="id" value="<?= $item['timesheet_id'] ?>"><button class="btn-danger">Supprimer</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<div id="modalForm" class="modal"><div class="modal-box"><h2>Ajouter</h2><form method="post" action="<?= App\Core\Helpers::url('timesheets/store') ?>"><label>date_travail<input name="date_travail" class="form-control"></label>
<label>worked_heures<input name="worked_heures" class="form-control"></label>
<label>etat<input name="etat" class="form-control"></label><div class="actions"><button type="button" onclick="closeModal('modalForm')">Annuler</button><button class="btn-primary">Enregistrer</button></div></form></div></div>
