<div class="page-head"><div><h1><?= App\Core\Helpers::e($title) ?></h1><p>Gestion du module Contrats Com</p></div><button class="btn-primary" onclick="openModal('modalForm')">+ Ajouter</button></div>
<div class="card"><table><thead><tr><th>reference</th><th>type_contrat</th><th>montant</th><th>periodicite</th><th>etat</th><th>Actions</th></tr></thead><tbody>
<?php foreach($items as $item): ?><tr><td><?= App\Core\Helpers::e($item['reference'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['type_contrat'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['montant'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['periodicite'] ?? '') ?></td><td><?= App\Core\Helpers::e($item['etat'] ?? '') ?></td><td><form method="post" action="<?= App\Core\Helpers::url('contrats-com/delete') ?>"><input type="hidden" name="id" value="<?= $item['contrat_id'] ?>"><button class="btn-danger">Supprimer</button></form></td></tr><?php endforeach; ?>
</tbody></table></div>
<div id="modalForm" class="modal"><div class="modal-box"><h2>Ajouter</h2><form method="post" action="<?= App\Core\Helpers::url('contrats-com/store') ?>"><label>reference<input name="reference" class="form-control"></label>
<label>type_contrat<input name="type_contrat" class="form-control"></label>
<label>montant<input name="montant" class="form-control"></label>
<label>periodicite<input name="periodicite" class="form-control"></label>
<label>etat<input name="etat" class="form-control"></label><div class="actions"><button type="button" onclick="closeModal('modalForm')">Annuler</button><button class="btn-primary">Enregistrer</button></div></form></div></div>
