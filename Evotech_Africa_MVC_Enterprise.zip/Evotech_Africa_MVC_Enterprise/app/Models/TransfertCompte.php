<?php
namespace App\Models;
use App\Core\Model;
class TransfertCompte extends Model {
    protected string $table = 'TRANSFERTS_COMPTE';
    protected string $primaryKey = 'transfert_id';
}
