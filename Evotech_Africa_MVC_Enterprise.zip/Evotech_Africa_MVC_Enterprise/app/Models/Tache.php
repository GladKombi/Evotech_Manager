<?php
namespace App\Models;
use App\Core\Model;
class Tache extends Model {
    protected string $table = 'TACHES';
    protected string $primaryKey = 'tache_id';
}
