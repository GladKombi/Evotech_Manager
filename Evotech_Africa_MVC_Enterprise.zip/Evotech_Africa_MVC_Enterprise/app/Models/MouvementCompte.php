<?php
namespace App\Models;
use App\Core\Model;
class MouvementCompte extends Model {
    protected string $table = 'MOUVEMENT_COMPTE';
    protected string $primaryKey = 'mouvement_id';
}
