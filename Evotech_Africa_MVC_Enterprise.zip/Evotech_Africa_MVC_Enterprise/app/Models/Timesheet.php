<?php
namespace App\Models;
use App\Core\Model;
class Timesheet extends Model {
    protected string $table = 'TIMESHEET';
    protected string $primaryKey = 'timesheet_id';
}
