<?php
namespace App\Models;
use App\Core\Model;
class Compte extends Model {
    protected string $table = 'COMPTES';
    protected string $primaryKey = 'compte_id';
}
