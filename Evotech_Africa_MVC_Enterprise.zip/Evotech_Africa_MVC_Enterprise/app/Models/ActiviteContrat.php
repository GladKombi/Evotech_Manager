<?php
namespace App\Models;
use App\Core\Model;
class ActiviteContrat extends Model {
    protected string $table = 'ACTIVITES_CONTRAT';
    protected string $primaryKey = 'activite_id';
}
