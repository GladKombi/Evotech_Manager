<?php
namespace App\Models;
use App\Core\Model;
class ContratCom extends Model {
    protected string $table = 'CONTRATS_COM';
    protected string $primaryKey = 'contrat_id';
}
