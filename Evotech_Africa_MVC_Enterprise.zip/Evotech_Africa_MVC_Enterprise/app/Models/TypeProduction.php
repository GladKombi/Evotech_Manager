<?php
namespace App\Models;
use App\Core\Model;
class TypeProduction extends Model {
    protected string $table = 'TYPES_PRODUCTION';
    protected string $primaryKey = 'type_prod_id';
}
