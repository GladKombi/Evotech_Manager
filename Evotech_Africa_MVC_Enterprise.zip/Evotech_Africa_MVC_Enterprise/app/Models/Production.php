<?php
namespace App\Models;
use App\Core\Model;
class Production extends Model {
    protected string $table = 'PRODUCTION';
    protected string $primaryKey = 'production_id';
}
