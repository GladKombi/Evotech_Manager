<?php
namespace App\Core;
class Helpers {
    public static function config(string $file): array { return require dirname(__DIR__,2)."/config/$file.php"; }
    public static function currentPath(): string { $url = $_GET['url'] ?? trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/'); return trim($url, '/') ?: '/'; }
    public static function url(string $path=''): string { $app=self::config('app'); return rtrim($app['base_url'],'/').'/'.ltrim($path,'/'); }
    public static function e(?string $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
    public static function redirect(string $path): void { header('Location: '.self::url($path)); exit; }
}
