<?php
namespace App\Core;
class Auth {
    public static function check(): bool { return isset($_SESSION['user']); }
    public static function requireAuth(): void { if(!self::check()) Helpers::redirect('login'); }
    public static function user(): ?array { return $_SESSION['user'] ?? null; }
}
